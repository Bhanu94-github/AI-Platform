import os
from pathlib import Path
import pymongo
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# --- Base Directory ---
BASE_DIR = Path(__file__).resolve().parent.parent

# --- Security ---
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'your-secret-key')
DEBUG = True
ALLOWED_HOSTS = []

# --- Installed Apps ---
INSTALLED_APPS = [
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'students',
    'instructors',
    'admin_panel',
]

# --- Middleware ---
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
]

# --- URL Configuration ---
ROOT_URLCONF = 'lets_do_it_django.urls'

# --- Templates ---
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# --- WSGI Application ---
WSGI_APPLICATION = 'lets_do_it_django.wsgi.application'

# --- SQLite Database ---
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# --- Static & Media Files ---
STATIC_URL = '/static/'
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# --- Sessions ---
SESSION_ENGINE = 'django.contrib.sessions.backends.db'

# --- Authentication ---
LOGIN_REDIRECT_URL = '/students/login-success/'

# --- External APIs ---
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# --- Default Auto Field ---
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ================================
# === MongoDB Configuration ====
# ================================

# --- MongoDB Configuration (FINAL) ---
import pymongo

# Instructor DB (for results and voice responses)
MONGO_CLIENT = pymongo.MongoClient("mongodb://localhost:27017/")
MONGO_DB_INSTRUCTOR = MONGO_CLIENT["instructor"]
MONGO_DB_SKILL = MONGO_CLIENT["skill_based"]
