from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    # Home Page
    path('', TemplateView.as_view(template_name='index.html'), name='home'),

    # Students Core App
    path('students/', include('students.urls')),

    # Instructors and Admin Panel
    path('instructors/', include('instructors.urls')),
    path('admin_panel/', include('admin_panel.urls')),

    # Assessments
    path('students/assessment/', include(('students.assessments.urls', 'student_assessments'), namespace='student_assessments')),
    path('voice/', include(('students.voice_assessment.urls', 'voice_assessment'), namespace='voice_assessment')),
    path('students/resume/', include(('students.resumeupload.urls', 'resumeupload'), namespace='resumeupload')),


]
